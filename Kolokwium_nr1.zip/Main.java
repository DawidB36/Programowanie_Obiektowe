public class Main {

    public static void printTable(int [] tab) {
        for (int i = 0; i < tab.length; i++) {
            System.out.print(tab[i] + " ");
        }
    }

    public static double absolute(double n) {
        if (n < 0)
            return -n;
        else
            return n;
    }

    public static int absolute(int n) {
        if (n < 0)
            return -n;
        else
            return n;
    }

    ///zad 1
    public static boolean dokladnosc(double x, double y, int k) {
        if (absolute(x - y) <= Math.pow(10, -k))
            return true;
        else
            return false;
    }

    ///zad 2
    public static int najblizszySasiad(int S) {

        if(S < 0) {
            System.out.println("Podana liczba nie może być ujemna!");
            return 0;
        }

        int current_distance = S ;
        int longest_distance = current_distance;
        int longest_distance_loc = 0;

        for (int i = 1; i < S; i++) {
            current_distance = absolute(S - (i * i));

            if (current_distance < longest_distance) {
                longest_distance = current_distance;
                longest_distance_loc = i;
            }
        }

        return longest_distance_loc;
    }

    ///zad 3
    public static double pierwiastek(int S, int n, int k) {
        double x = najblizszySasiad(S);

        return pierw_rek(x, S, n, k);
    }

    public static double pierw_rek(double x, int S, int n, int k) {
        double output = (x + (S / x)) / n;

        if (dokladnosc(S, output * output, k)) {
            return output;
        }
        else {
            pierw_rek(output, S, n, k);
            return output;
        }
    }

    ///zad 4
    public static int podciag(int[] tab) {
        int maxLength = 1, currentLength = 1;

        for (int i = 1; i < tab.length; i++) {
            if (tab[i - 1] > tab[i]) {
                currentLength++;
            }
            else {

                if (currentLength > maxLength) {
                    maxLength = currentLength;
                }

                currentLength = 1;
            }
        }

        if (currentLength > maxLength) {
            maxLength = currentLength;
        }

        return maxLength;
    }

    ///zad 5
    public static int podciag(int[] tab, int r) {
        int maxLength = 1, currentLength = 1;

        for (int i = 1; i < tab.length; i++) {
            if (tab[i - 1] - r == tab[i]) {
                currentLength++;
            }
            else {

                if (currentLength > maxLength) {
                    maxLength = currentLength;
                }

                currentLength = 1;
            }
        }

        if (currentLength > maxLength) {
            maxLength = currentLength;
        }

        return maxLength;
    }

    ///zad 6
    public static boolean czyPalindrom(int n) {
        int original = n;
        int reversed = 0;

        while (n != 0) {
            int digit = n % 10;
            reversed = reversed * 10 + digit;
            n /= 10;
        }

        return original == reversed;
    }

    ///zad 7
    public static void palindromLiczbowy(int m) {
        int min = 1;
        int max = 0;
        int product = 0;

        for (int i = 1; i < m; i++) {
            min *= 10;
        }

        for (int i = 1; i <= m; i++) {
            max *= 10;
            max += 9;
        }

        for (int i = min; i <= max; i++) {
            for (int j = min; j <= max; j++) {
                product = i * j;
                if(czyPalindrom(product)) {
                    System.out.print(String.format("%d * %d = %d \n", i, j, product));
                }
            }
        }
    }

    public static void main(String[] args) {
        ///zad 1
        System.out.println("Zadanie 1:");
        System.out.println("Czy różnica 10 i 9.99 spełnia dokładność 10^-2:");

        System.out.println(dokladnosc(10, 9.99, 2));

        System.out.println("");

        ///zad 2
        System.out.println("Zadanie 2:");
        System.out.println("Najbliższa liczba sąsiadująca z pierwiastkiem z 20:");

        System.out.println(najblizszySasiad(20));

        System.out.println("");

        ///zad 3
        System.out.println("Zadanie 3:");
        System.out.println("Pierwiastek z liczby 20 z dokładnością 10^-2:");

        System.out.println(pierwiastek(20, 2, 2));

        System.out.println("");

        ///zad 4
        System.out.println("Zadanie 4:");
        System.out.println("Ciąg:");

        int[] tab4 = {5, 4, 6, 2, 4, 3, 2};
        printTable(tab4);

        System.out.println("");

        System.out.println("Długość najdłuższego podciągu malejącego:");
        System.out.println(podciag(tab4));

        System.out.println("");

        ///zad 5
        System.out.println("Zadanie 5:");
        System.out.println("Ciąg:");

        int[] tab5 = {5, 3, 6, 4, 2, 0, 2};
        printTable(tab5);

        System.out.println("");

        System.out.println("Długość najdłuższego podciągu malejącego o 2:");
        System.out.println(podciag(tab5, 2));

        System.out.println("");

        ///zad 6
        System.out.println("Zadanie 6:");
        System.out.println("Czy liczba jest 1234321 palindromem:");

        System.out.println(czyPalindrom(1234321));

        System.out.println("");

        ///zad 7
        System.out.println("Zadanie 7:");
        System.out.println("Wszystkie liczby 2 cyfrowe będące palindromem liczbowym:");

//        palindromLiczbowy(2);
    }


}