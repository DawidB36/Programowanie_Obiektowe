public class Pair<T> {
    private T el1;
    private T el2;

    public Pair(T el1, T el2) {
        this.el1 = el1;
        this.el2 = el2;
    }

    public T getEl1() {
        return el1;
    }

    public void setEl1(T el1) {
        this.el1 = el1;
    }

    public T getEl2() {
        return el2;
    }

    public void setEl2(T el2) {
        this.el2 = el2;
    }

    @Override
    public String toString() {
        return "Pair{" +
                "el1=" + el1 +
                ", el2=" + el2 +
                '}';
    }
}
