public class Dog extends Animal {
    private String breed;
    private int age;

    public Dog(String name,int age, int weight, String breed) {
        super(name, weight);
        this.breed = breed;
        this.age = age;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + super.getName() +
                ", age=" + age +
                ", weight=" + super.getWeight() +
                ", breed='" + breed + '\'' +
                "}";
    }
}
