import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Box<T>{
    T obiekt;

    public Box(T obiekt) {
        this.obiekt = obiekt;
    }

    public T getObiekt() {
        return obiekt;
    }

    public void setObiekt(T obiekt) {
        this.obiekt = obiekt;
    }

    @Override
    public String toString() {
        return "Box{" +
                "obiekt=" + obiekt +
                '}';
    }

}

class Counter<T>{
    List<T> lista = new ArrayList<T>();

    public void add(T obiekt){
        lista.add(obiekt);
    }

    public int getCount(){
        return lista.size();
    }
}

public class Main {
    public static <T> boolean isEqual(T a, T b) {
        return a.equals(b);
    }

    public static <T> void swap(T[] tab, int id1, int id2) {
        T temp = tab[id1];
        tab[id1] = tab[id2];
        tab[id2] = temp;
    }

    public static <T extends Animal> T findMax(T element1, T element2) {
        if (element1.getWeight() > element2.getWeight())
            return element1;
        else
            return element2;
    }

    public static <T> void findMinMaxAge(ArrayList<Dog> dogList, Pair<?super Dog> result) {
        Dog min = dogList.getFirst();
        Dog max = dogList.getFirst();
        for (Dog d : dogList) {
            if (d.getAge() < min.getAge()){
                min = d;
            }
            if (d.getAge() > max.getAge()){
                max = d;
            }
        }

        result.setEl1(min);
        result.setEl2(max);
    }

    public static void main(String[] args) {
        Box<String> b1 = new Box<>(null);
        b1.setObiekt("1357");
        System.out.println(b1.getObiekt());

        Box<Integer> b2 = new Box<>(1357);
        System.out.println(b2.getObiekt());

        Box<Integer> b3 = new Box<>(1357);
        System.out.println(b3.getObiekt());

        System.out.println(isEqual(b1.getObiekt(), b2.getObiekt()));
        System.out.println(isEqual(b2.getObiekt(), b3.getObiekt()));

        Integer[] tab1 = {0, 1, 5, 3, 4, 2};

        for (Integer i : tab1) {
            System.out.print(i+" ");
        }
        System.out.print("\n");

        swap(tab1, 2, 5);

        for (Integer i : tab1) {
            System.out.print(i+" ");
        }
        System.out.print("\n");

        Animal horse1 = new Animal("Aniszkiewicz", 500);
        Dog dog1 = new Dog("Mykel", 6, 43, "Doberman");

        System.out.println(findMax(horse1, dog1));

        Dog dog2 = new Dog("Rex", 3, 33, "German shepard");
        Dog dog3 = new Dog("Ares", 7, 31, "German shepard");
        Dog dog4 = new Dog("Cupcake", 6, 42, "Bulldog");

        Pair<Dog> dogMinMax = new Pair<>(null, null);

        ArrayList<Dog> dogList = new ArrayList<>();
        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
        dogList.add(dog4);

        findMinMaxAge(dogList, dogMinMax);

        System.out.println(dogMinMax);
    }
}