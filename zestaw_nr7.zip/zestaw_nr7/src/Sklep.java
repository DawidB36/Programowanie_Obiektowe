import java.util.ArrayList;

public class Sklep {
    ArrayList<Produkt> produkty;

    public Sklep(ArrayList<Produkt> list) {
        produkty = list;
    }

    public void dodajProdukt(Produkt goods) {
        produkty.add(goods);
    }

//    public void wyswietlOferty() {
//        System.out.println("Oferty sklepu:");
//        for(int i = 0; i < produkty.size(); i++) {
//            System.out.println(String.format("%s Cena: %.2f Ilość: %d", produkty.get(i).nazwa,
//                    produkty.get(i).cena, produkty.get(i).iloscNaMagazynie));
//        }
//    }
}
