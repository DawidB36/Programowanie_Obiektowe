import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        System.out.println("Zadanie 1:");
        Produkt pomidor = new Produkt("Pomidor", 3.5);
        Produkt marchew = new Produkt("Marchew", 4.5);
        Produkt seler = new Produkt("Seler", 5);

        ArrayList<Produkt> p_list = new ArrayList<>();
        p_list.add(pomidor);
        p_list.add(marchew);
        p_list.add(seler);

        ArrayList<Integer> p_list1_quant = new ArrayList<Integer>();
        p_list1_quant.add(10);
        p_list1_quant.add(20);
        p_list1_quant.add(15);

        Magazyn magazyn = new Magazyn(p_list, p_list1_quant);

        magazyn.wyswietl();

        Adres a1 = new Adres("Witosa", 7, "Olsztyn", 11211);
        Adres a2 = new Adres("Witosa", 6, 13, "Olsztyn", 11212);

        a1.pokaz();
        a2.pokaz();

        System.out.println(a1.przed(a2));
    }
}