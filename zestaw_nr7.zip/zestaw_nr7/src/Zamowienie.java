import java.util.ArrayList;

public class Zamowienie {
    KoszykZakupowy koszyk;
    String statusZamowienia;
    String platnosc;

    public Zamowienie(KoszykZakupowy cart, String status, String payment) {
        koszyk = cart;
        statusZamowienia = status;
        platnosc = payment;
    }

    public void ustawStatusZamowienia(String status) {
        statusZamowienia = status;
    }

//    public void wyswietlZamowienia() {
//        koszyk.wyswietlZawartoscKoszyka();
//        System.out.println(String.format("Status: %s", statusZamowienia));
//    }

    public void finalizujZamowienie() {
        if (platnosc == "Opłacone") {
            statusZamowienia = "Gotowe do wysyłki";
        }
    }

//    public void zwrocProdukt(String name, int quantity) {
//        ArrayList<Produkt> temp = koszyk.listaProdukt;
//
//        if (temp.contains(name)) {
//            for(int i=0; i<temp.size(); i++) {
//                if (temp.get(i).nazwa == name) {
//                    if (quantity <= temp.get(i).iloscNaMagazynie) {
//                        temp.get(i).iloscNaMagazynie = temp.get(i).iloscNaMagazynie - quantity;
//                    }
//                    else {
//                        temp.get(i).iloscNaMagazynie = 0;
//                    }
//                }
//            }
//        }
//
//    }
}
