public class Produkt {
    String nazwa;
    double cena;

    public Produkt(String name, double price) {
        nazwa = name;
        cena = price;
    }

    public void wyswietlInformacje() {
        System.out.println(String.format("Nazwa: %s Cena: %.2f Ilość: %d", nazwa, cena));
    }
}
