public class Adres {
    public String ulica;
    public int numerDomu;
    public int numerMieszkania = 0;
    public String miasto;
    public int kodPocztowy;

    public Adres (String ulica, int numerDomu, String miasto,  int kodPocztowy) {
        this.ulica = ulica;
        this.numerDomu = numerDomu;
        this.miasto = miasto;
        this.kodPocztowy = kodPocztowy;
    }

    public Adres (String ulica, int numerDomu, int numerMieszkania, String miasto,  int kodPocztowy) {
        this.ulica = ulica;
        this.numerDomu = numerDomu;
        this.numerMieszkania = numerMieszkania;
        this.miasto = miasto;
        this.kodPocztowy = kodPocztowy;
    }

    public void pokaz() {
        if(this.numerMieszkania == 0) {
            System.out.println(String.format("%,d %s", this.kodPocztowy, this.miasto));
            System.out.println(String.format("%s %d", this.ulica, this.numerDomu));
        }
        else {
            System.out.println(String.format("%,d %s", this.kodPocztowy, this.miasto));
            System.out.println(String.format("%s %d/%d", this.ulica, this.numerDomu, this.numerMieszkania));
        }
    }

    public boolean przed(Adres comp_addr) {
        if(this.kodPocztowy < comp_addr.kodPocztowy)
            return true;
        else
            return false;
    }
}
