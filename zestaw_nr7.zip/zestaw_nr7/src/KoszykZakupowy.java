import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class KoszykZakupowy {
    HashMap<Produkt, Integer> listaProdukt = new HashMap<Produkt, Integer>();


    public KoszykZakupowy(ArrayList<Produkt> list, ArrayList<Integer> quantity) {
        for (int i = 0; i < list.size(); i++) {
            listaProdukt.put(list.get(i), quantity.get(i));
        }
    }

    public void dodajProdukt(Magazyn storage, Produkt goods, int quantity) {
        if (storage.produkty.get(goods.nazwa) >= quantity) {
            listaProdukt.put(new Produkt(goods.nazwa, goods.cena), quantity);
            storage.produkty.put(goods, storage.produkty.get(goods.nazwa) - quantity);
        }
    }

//    public void wyswietlZawartoscKoszyka() {
//        System.out.println("Zawartość koszyka:");
//        for (Map.Entry(Produkt, Integer) kosz : this.listaProdukt.entrySet()) {
//            System.out.print(String.format("Nazwa: %s Cena: %.2f Ilość: %d\n", listaProdukt.get(i).nazwa,
//                    listaProdukt.get(i)., listaProdukt.get(i).iloscNaMagazynie));
//        }
//    }

//    public double obliczCalkowitaWartosc() {
//        double total = 0;
//        for (int i = 0; i < listaProdukt.size(); i++) {
//            total += listaProdukt.get(i).cena * listaProdukt.get(i).iloscNaMagazynie;
//        }
//
//        return total;
//    }
}
