import java.util.ArrayList;

public class Klient {
    String imie;
    String nazwisko;
    Adres adres;
    ArrayList<Zamowienie> listaZamowien;

    public Klient(String name, String surname, ArrayList<Zamowienie> list) {
        imie = name;
        nazwisko = surname;
        listaZamowien = list;
    }

    public void dodajZamowienie(Zamowienie goods) {
        listaZamowien.add(goods);
    }

//    public void wyswietlHistorieZamowien() {
//        System.out.println(String.format("Historia zamówień klienta: %s %s\n", imie, nazwisko));
//        for(int i = 0; i < listaZamowien.size(); i++) {
//            listaZamowien.get(i).wyswietlZamowienia();
//            System.out.println("");
//        }
//    }

//    public double obliczLacznyKosztZamowien() {
//        double total = 0;
//
//        for (int i = 0; i < listaZamowien.size(); i++) {
//            total += listaZamowien.get(i).koszyk.obliczCalkowitaWartosc();
//        }
//
//        return total;
//    }
}
