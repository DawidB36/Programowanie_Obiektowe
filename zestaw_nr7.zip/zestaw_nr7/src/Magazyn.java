import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Magazyn {
    HashMap<Produkt, Integer> produkty = new HashMap<Produkt, Integer>();

    public Magazyn(ArrayList<Produkt> product, ArrayList<Integer> quantity) {
        for (int i = 0; i < product.size(); i++) {
            produkty.put(product.get(i), quantity.get(i));
        }
    }

    public void wyswietl() {
        for (Map.Entry<Produkt, Integer> p : produkty.entrySet()) {
            System.out.println(String.format("Produkt: %s, Ilość: %d", p.getKey().nazwa, p.getValue()));
        }
    }
}
