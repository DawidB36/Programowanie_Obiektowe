public class Platnosc {
    double kwota;
    String statusPlatnosci = "Do zapłaty";

    public Platnosc(double price, String status) {
        kwota = price;
        statusPlatnosci = status;
    }

    public void zaplac() {
        statusPlatnosci = "Opłacone";
        kwota = 0;
    }
}
