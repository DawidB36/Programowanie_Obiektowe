import java.util.*;

public class Main {
    public static <T> void printUnique(Collection<T> items) {
        Set<T> uniqueElement = new HashSet<>(items);

        for(T item: uniqueElement) {
            System.out.println(item);
        }
    }

    public static <T> ArrayList<T> mergeLists(ArrayList<T> first, ArrayList<T> second) {
        ArrayList<T> merged = new ArrayList<>();

        merged.addAll(first);
        merged.addAll(second);

        return merged;
    }

    public static <T> Boolean isPalindrome(LinkedList<T> items) {
        boolean isPalindrome = true;
        int size = items.size() - 1;

        for (int i = 0; i <= size / 2; i++) {
            if (items.get(i) != items.get(size - i)) {
                isPalindrome = false;
                break;
            }
        }

        return isPalindrome;
    }

    public static <T> HashSet<T> findUniqueElements(List<T> items) {
        return new HashSet<>(items);
    }

    public static <T> TreeSet<T> findElementsInRange(TreeSet<T> mainTreeSet, T lowerBound, T upperBound) {
        TreeSet<T> subTreeSet = new TreeSet<>();

        boolean flag = false;

        for (T item : mainTreeSet) {
            if (item.equals(lowerBound))
                flag = true;

            if(flag)
                subTreeSet.add(item);

            if (item.equals(upperBound))
                flag = false;
        }

        return subTreeSet;
    }

    public static <K, V> HashMap<V, Integer> countValueOccurrences(HashMap<K, V> map) {
        HashMap<V, Integer> occurrences = new HashMap<>();

        for (K key : map.keySet()) {
            if (occurrences.containsKey(map.get(key))) {
                occurrences.put(map.get(key), occurrences.get(map.get(key)) + 1);
            }
            else
                occurrences.put(map.get(key), 1);
        }

        return occurrences;
    }

    public static <K, V> TreeMap<K, V> subMapInRange(TreeMap<K, V> mainTreeMap, K startKey, K endKey) {
        TreeMap<K, V> subTreeMap = new TreeMap<>();

        boolean flag = false;

        for (K key : mainTreeMap.keySet()) {
            if (key == startKey)
                flag = true;

            if(flag)
                subTreeMap.put(key, mainTreeMap.get(key));

            if (key == endKey)
                flag = false;
        }

        return subTreeMap;
    }

    public static void main(String[] args) {
//        TreeSet treeSet = new TreeSet();
//
//        treeSet.add(1);
//        treeSet.add(5);
//        treeSet.add(3);
//        treeSet.add(2);
//        treeSet.add(5);
//        treeSet.add(6);
//        treeSet.add(1);
//        treeSet.add(10);
//        treeSet.add(7);
//
//        System.out.println(treeSet);
//
//        System.out.println(findElementsInRange(treeSet, 5, 10));
//
//        TreeSet treeSetString = new TreeSet();
//
//        treeSetString.add("a");
//        treeSetString.add("g");
//        treeSetString.add("u");
//        treeSetString.add("aaaa");
//        treeSetString.add("u");
//        treeSetString.add("i");
//        treeSetString.add("u");
//        treeSetString.add("bb");
//        treeSetString.add("t");
//
//        System.out.println(treeSetString);
//
//        System.out.println(findElementsInRange(treeSetString, "bb", "t"));

//        LinkedList<String> cars = new LinkedList<String>();
//        cars.add("Volvo");
//        cars.add("BMW");
//        cars.add("Ford");
//        cars.add("Mazda");
//        cars.add("Mazda");
//        cars.add("Ford");
//        cars.add("BMW");
//        cars.add("Volvo");
//
//        System.out.println(cars);
//
//        System.out.println(isPalindrome(cars));

//        List<Integer> list = new ArrayList<>();
//        list.add(1);
//        list.add(1);
//        list.add(2);
//        list.add(2);
//        list.add(2);
//        list.add(5);
//        list.add(8);
//
//        System.out.println(list);
//        System.out.println(findUniqueElements(list));

//        HashMap<Integer, String> map = new HashMap<>();
//
//        map.put(0, "a");
//        map.put(1, "a");
//        map.put(2, "a");
//        map.put(3, "b");
//        map.put(4, "b");
//        map.put(5, "c");
//        map.put(6, "d");
//        map.put(7, "y");
//        map.put(8, "u");
//        map.put(9, "u");
//
//        System.out.println(map);
//
//        System.out.println(countValueOccurrences(map));

        TreeMap<String, Integer> treeMap = new TreeMap<>();

        treeMap.put("a", 1);
        treeMap.put("b", 2);
        treeMap.put("d", 3);
        treeMap.put("c", 4);
        treeMap.put("h", 5);
        treeMap.put("i", 6);
        treeMap.put("f", 7);
        treeMap.put("g", 8);

        System.out.println(treeMap);

        System.out.println(subMapInRange(treeMap, "b", "g"));
    }
}