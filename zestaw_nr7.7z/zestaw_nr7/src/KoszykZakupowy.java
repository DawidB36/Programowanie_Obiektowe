import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class KoszykZakupowy {
    HashMap<Produkt, Integer> listaProdukt = new HashMap<Produkt, Integer>();


    public KoszykZakupowy(ArrayList<Produkt> list, ArrayList<Integer> quantity) {
        for (int i = 0; i < list.size(); i++) {
            this.listaProdukt.put(list.get(i), quantity.get(i));
        }
    }

    public void dodajProdukt(Magazyn storage, Produkt goods, int quantity) {
        if (storage.produkty.get(goods) >= quantity) {
            this.listaProdukt.put(new Produkt(goods.nazwa, goods.cena), quantity);
            storage.produkty.put(goods, storage.produkty.get(goods) - quantity);
        }
    }

    public void zwrocProdukt(Magazyn storage, Produkt goods, int quantity) {
        if (this.listaProdukt.get(goods) >= quantity) {
            listaProdukt.put(goods, this.listaProdukt.get(goods) - quantity);
            storage.produkty.put(goods, storage.produkty.get(goods) + quantity);
        }
    }

    @Override
    public String toString() {
        String output = "";

        System.out.println("Zawartość koszyka:");
        for (Map.Entry<Produkt, Integer> kosz: this.listaProdukt.entrySet()) {
            output += String.format("Nazwa: %s Cena: %.2f Ilość: %d\n", kosz.getKey().nazwa,
                    kosz.getKey().cena, kosz.getValue());
        }

        return output;
    }

//    public void wyswietlZawartoscKoszyka() {
//        System.out.println("Zawartość koszyka:");
//        for (Map.Entry<Produkt, Integer> kosz: this.listaProdukt.entrySet()) {
//            System.out.print(String.format("Nazwa: %s Cena: %.2f Ilość: %d\n", kosz.getKey().nazwa,
//                    kosz.getKey().cena, kosz.getValue()));
//        }
//    }

    public double obliczCalkowitaWartosc() {
        double total = 0;
        for (Map.Entry<Produkt, Integer> kosz: this.listaProdukt.entrySet()) {
            total += kosz.getKey().cena * kosz.getValue();
        }

        return total;
    }
}
