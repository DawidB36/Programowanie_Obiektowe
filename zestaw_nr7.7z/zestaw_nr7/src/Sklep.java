import java.time.LocalDate;
import java.util.ArrayList;

public class Sklep {
    ArrayList<Produkt> produkty;
    String nazwaSklepu;
    LocalDate dataPowstania;
    Magazyn magazynSklepu;

    public Sklep(ArrayList<Produkt> list, String nazwaSklepu, String dataPowstania, Magazyn magazynSklepu) {
        if (LocalDate.now().isAfter(LocalDate.parse(dataPowstania))) {
            produkty = list;
            this.nazwaSklepu = nazwaSklepu;
            this.dataPowstania = LocalDate.parse(dataPowstania);
            this.magazynSklepu = magazynSklepu;
        }
        else {
            throw new IllegalArgumentException("Data powstania nie może być w przyszłości!");
        }
    }

    public void dodajProdukt(Produkt goods) {
        produkty.add(goods);
    }

    public void wyswietlOferty(Magazyn storage) {
        System.out.println("Oferty sklepu:");
        for (Produkt produkt : produkty) {
            System.out.printf("%s Cena: %.2f Ilość: %d%n", produkt.nazwa,
                    produkt.cena, storage.produkty.get(produkt));
        }
    }
}
