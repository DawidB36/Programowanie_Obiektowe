import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        System.out.println("Zadanie 1:");
        Produkt pomidor = new Produkt("Pomidor", 3.5);
        Produkt marchew = new Produkt("Marchew", 4.5);
        Produkt seler = new Produkt("Seler", 5);

        System.out.println(pomidor);
        System.out.println("");

        ArrayList<Produkt> p_list = new ArrayList<>();
        p_list.add(pomidor);
        p_list.add(marchew);
        p_list.add(seler);

        ArrayList<Integer> p_list1_quant = new ArrayList<Integer>();
        p_list1_quant.add(10);
        p_list1_quant.add(20);
        p_list1_quant.add(15);

        Magazyn magazyn = new Magazyn(p_list, p_list1_quant);

        magazyn.wyswietl();

        System.out.println("");

        ArrayList<Produkt> k_list1 = new ArrayList<>();
        k_list1.add(pomidor);
        k_list1.add(marchew);

        ArrayList<Integer> k_list1_quant = new ArrayList<Integer>();
        k_list1_quant.add(1);
        k_list1_quant.add(4);

        KoszykZakupowy koszyk = new KoszykZakupowy(k_list1, k_list1_quant);

        System.out.println(koszyk);

        System.out.println("");

        koszyk.dodajProdukt(magazyn, seler, 3);

        magazyn.wyswietl();
        System.out.println("");

        System.out.println(koszyk);
        System.out.println("");

        koszyk.zwrocProdukt(magazyn, marchew, 3);

        magazyn.wyswietl();
        System.out.println("");

        System.out.println(koszyk);
        System.out.println("");

        System.out.printf("Łączny koszt za koszyk: %.2f\n", koszyk.obliczCalkowitaWartosc());
        System.out.println("");

        Zamowienie zm = new Zamowienie(koszyk, "Wysłane", "Opłacone");

        System.out.println(zm);
        System.out.println("");

        zm.ustawStatusZamowienia("Oczekiwanie na płatność");
        System.out.println(zm);
        System.out.println("");

        zm.finalizujZamowienie();
        System.out.println(zm);
        System.out.println("");

        Adres a1 = new Adres("Witosa", 7, "Olsztyn", 11211);
        Adres a2 = new Adres("Witosa", 6, 13, "Olsztyn", 11212);

        a1.pokaz();
        a2.pokaz();

        System.out.println(a1.przed(a2));

        ArrayList<Zamowienie> zmlist = new ArrayList<>();
        zmlist.add(zm);

        Klient ignacy = new Klient("Ignacy", "Gouda", a1, zmlist);
        System.out.println(ignacy);
        System.out.printf("Koszt: %.2f", ignacy.obliczLacznyKosztZamowien());
        System.out.println("");
    }
}