import java.util.ArrayList;

public class Zamowienie {
    KoszykZakupowy koszyk;
    String statusZamowienia;
    String platnosc;

    public Zamowienie(KoszykZakupowy cart, String status, String payment) {
        koszyk = cart;
        statusZamowienia = status;
        platnosc = payment;
    }

    public void ustawStatusZamowienia(String status) {
        statusZamowienia = status;
    }

    @Override
    public String toString() {
        String output = String.format("%s\nStatus: %s Płatność: %s\n", koszyk.toString(), statusZamowienia, platnosc);
        return output;
    }

//    public void wyswietlZamowienia() {
//        System.out.println(koszyk);
//        System.out.printf("Status: %s Płatność: %s\n", statusZamowienia, platnosc);
//    }

    public void finalizujZamowienie() {
        if (platnosc == "Opłacone") {
            statusZamowienia = "Gotowe do wysyłki";
        }
    }
}
