import java.util.ArrayList;

public class Klient {
    String imie;
    String nazwisko;
    Adres adres;
    ArrayList<Zamowienie> listaZamowien;

    public Klient(String name, String surname, Adres address, ArrayList<Zamowienie> list) {
        imie = name;
        nazwisko = surname;
        listaZamowien = list;
        adres = address;
    }

    public void dodajZamowienie(Zamowienie goods) {
        listaZamowien.add(goods);
    }

    @Override
    public String toString() {
        String output = String.format("Historia zamówień klienta: %s %s\n", imie, nazwisko);
        for (Zamowienie zamowienie : listaZamowien) {
            output += zamowienie.toString() + "\n";
        }
        return output;
    }

//    public void wyswietlHistorieZamowien() {
//        System.out.println(String.format("Historia zamówień klienta: %s %s\n", imie, nazwisko));
//        for(int i = 0; i < listaZamowien.size(); i++) {
//            System.out.println(listaZamowien.get(i));
//            System.out.println("");
//        }
//    }

    public double obliczLacznyKosztZamowien() {
        double total = 0;

        for (int i = 0; i < listaZamowien.size(); i++) {
            total += listaZamowien.get(i).koszyk.obliczCalkowitaWartosc();
        }

        return total;
    }
}
