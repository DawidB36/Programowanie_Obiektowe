public class Produkt {
    String nazwa;
    double cena;

    public Produkt(String name, double price) {
        nazwa = name;
        cena = price;
    }

    @Override
    public String toString() {
        return "Produkt [nazwa=" + nazwa + ", cena=" + cena + "]";
    }

//    public void wyswietlInformacje() {
//        System.out.printf("Nazwa: %s Cena: %.2f \n", nazwa, cena);
//    }
}
